import React from 'react'
import {Button} from 'react-bootstrap'
 

const CreateUserButton = (props)=>{
  return (
    <Button variant="success" > 
    Create Users
    </Button>
  )
}
export default CreateUserButton