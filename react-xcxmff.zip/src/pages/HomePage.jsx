import React from 'react';
import UsersMainPage from './../components/UsersMainPage/UsersMainPage';

const HomePage = () => {
  return (
    <div className="container">
      <UsersMainPage />
    </div>
  );
};
export default HomePage;
